<script setup lang="ts">
import NavBar from "../components/NavBar.vue"
</script>

<template>
  <main>
    <NavBar/>
    <h1>Main page</h1>
  </main>
</template>
